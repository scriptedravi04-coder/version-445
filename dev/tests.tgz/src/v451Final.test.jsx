// v451 — renders of the new brand + creator screens (BRD Part B final batch + Ravi's 18 Nov list).
import { describe, it, expect, vi, beforeEach } from "vitest";
import React from "react";
import { readFileSync } from "fs";
import { render, screen, fireEvent, act, cleanup } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";

const apiMock = vi.hoisted(() => ({ get: vi.fn(() => Promise.resolve({ data: [] })), post: vi.fn(() => Promise.resolve({ data: { ok: true } })) }));
vi.mock("./lib/api", () => ({ api: apiMock, isBrandLike: (u) => ["brand", "agency", "talent_manager"].includes(String((u && typeof u === "object" ? u.role : u) || "").toLowerCase()) }));
vi.mock("sonner", () => ({ toast: Object.assign(vi.fn(), { success: vi.fn(), error: vi.fn(), warning: vi.fn() }) }));
vi.mock("./lib/supabase", () => ({ supabase: null }));

import PreferencesScreen from "./components/profile/mobile/brand/PreferencesScreen";
import HelpScreen from "./components/profile/mobile/brand/HelpScreen";
import { waHelpMessage, WhatsAppHelpHost, openWhatsAppHelp } from "./components/help/SupportContactCard";
import UgcHomeHeader from "./pages/brand/brandUgc/UgcHomeHeader";
import PhotoLedHeaderMobile, { GreenTick } from "./components/publicProfile/PhotoLedHeaderMobile";
import PortfolioCoversMobile from "./components/publicProfile/PortfolioCoversMobile";
import { extraMatch, sortCreators, filterCount, applyFilters } from "./components/explore/mobile/ExploreMobile";
import { PushPage } from "./components/common/Popup";

beforeEach(() => { cleanup(); apiMock.get.mockClear(); apiMock.post.mockClear(); });

describe("BRD §27 preferences — 5 rows, open one, auto-save", () => {
  it("shows answers in the rows, opens one row, and saves by itself", async () => {
    vi.useFakeTimers();
    const onSave = vi.fn(() => Promise.resolve(true));
    render(<PreferencesScreen onBack={() => {}} onSave={onSave} profile={{ campaignTypes: "barter", budgetRange: "Under ₹10,000", creatorSize: "Micro (10K-100K)", niches: "Food", genderFocus: "Women" }} />);
    expect(screen.getByTestId("pref-row-type").textContent).toMatch(/Barter \/ product/);
    expect(screen.getByTestId("pref-row-size").textContent).toMatch(/Mid-size \(10K–100K\)/);
    expect(screen.getByTestId("pref-row-audience").textContent).toMatch(/Mostly women/);
    expect(screen.queryByText("Save preferences")).toBeNull();
    fireEvent.click(screen.getByTestId("pref-row-budget").querySelector("button"));
    fireEvent.click(screen.getByText("₹2L+"));
    await act(async () => { vi.advanceTimersByTime(800); });
    vi.useRealTimers();
    expect(onSave).toHaveBeenCalledTimes(1);
    expect(onSave.mock.calls[0][0].budgetRange).toBe("₹2L+");
    expect(onSave.mock.calls[0][1]).toEqual({ silent: true });
  });
});

describe("BRD §8c Help — one page", () => {
  it("search, 4 topics (one name each), Still stuck with Chat / WhatsApp / Email, no legal links", async () => {
    apiMock.get.mockImplementation(() => Promise.resolve({ data: [{ ticket_id: "t1", status: "OPEN", category: "Payments", created_at: new Date().toISOString() }] }));
    render(<MemoryRouter><HelpScreen onBack={() => {}} /></MemoryRouter>);
    expect(screen.getByLabelText("Search help")).toBeTruthy();
    for (const id of ["payments", "campaigns", "kyc", "trust_safety"]) expect(screen.getByTestId(`help-topic-${id}`)).toBeTruthy();
    expect(screen.getByTestId("help-still-stuck").textContent).toMatch(/Chat with us.*WhatsApp.*Email/s);
    expect(await screen.findByTestId("help-open-ticket")).toBeTruthy();
    expect(screen.queryByText(/Delete account/)).toBeNull();
  });
});

describe("BRD §16 WhatsApp sheet", () => {
  it("builds the message and only opens WhatsApp once topic + issue are picked", async () => {
    expect(waHelpMessage({ brandName: "Nova", userId: "b1", role: "brand", topic: "Payments", issue: "GST invoice", details: "need March", orderId: "o9" }))
      .toBe('Hi Ybex, I\'m Nova (brand · ID b1).\nTopic: Payments → GST invoice\n"need March"\nOrder: o9');
    const open = vi.spyOn(window, "open").mockImplementation(() => null);
    render(<WhatsAppHelpHost user={{ user_id: "b1", role: "brand" }} brandName="Nova" />);
    act(() => openWhatsAppHelp({ topic: "Payments" }));
    const go = await screen.findByTestId("wa-help-go");
    expect(go.disabled).toBe(true);
    fireEvent.click(screen.getByText("GST invoice"));
    expect(go.disabled).toBe(false);
    fireEvent.click(go);
    expect(open.mock.calls[0][0]).toMatch(/^https:\/\/wa\.me\/918764004299\?text=Hi%20Ybex/);
    expect(apiMock.post).toHaveBeenCalledWith("/support/tickets", expect.objectContaining({ category: "Payments" }));
    open.mockRestore();
  });
});

describe("BRD §22 Instant UGC header", () => {
  it("solid header, Guide only (no Search / Refresh), short line, segmented tabs", () => {
    render(<MemoryRouter><UgcHomeHeader activeTab="briefs" briefs={[1, 2]} orders={[]} setActiveTab={() => {}} fetchData={() => {}} refreshing={false} /></MemoryRouter>);
    const h = screen.getByTestId("ugc-home-header");
    expect(h.className).not.toMatch(/backdrop-blur|bg-white\/95/);
    expect(screen.queryByLabelText("Search")).toBeNull();
    expect(screen.queryByLabelText("Refresh")).toBeNull();
    expect(h.textContent).toMatch(/Verified creators · 24–72h delivery/);
    expect(screen.getAllByRole("tab").map((x) => x.textContent)).toEqual(["My briefs2", "Orders0"]);
  });
});

describe("BRD §12 / §14 creator profile (light, pager, green tick, work grid)", () => {
  const c = { name: "Aanya Shah", instagram_handle: "aanya", city: "Jaipur", category: "Beauty", ig_followers: 52000, avg_views_30d: 9100, avg_likes_30d: 820, engagement_rate: 3.4,
    bio: "Skincare & sunsets" };
  const items = [
    { cover: "a.jpg", brand_name: "Lakme", views: 900, url: "https://instagram.com/reel/1" },
    { cover: "b.jpg", brand_name: "Lakme", views: 5000, url: "https://instagram.com/reel/2" },
    { cover: "c.jpg", brand_name: "Mamaearth", views: 100, url: "https://instagram.com/reel/3" },
  ];
  it("one light theme, 4 tabs in a pager, green tick only when verified, plain stats row", () => {
    render(<PhotoLedHeaderMobile c={c} photoUrl="p.jpg" verified portfolioItems={items} viewer={{ isBrand: true, loggedIn: true }} cta={{ label: "Send collab request", onClick: () => {} }} />);
    expect(screen.getByTestId("public-profile-photo-led").getAttribute("data-theme")).toBe("light");
    expect(screen.getAllByRole("tab").map((x) => x.textContent)).toEqual(["Work", "Reviews", "About", "Rates"]);
    expect(screen.getByTestId("profile-pager").style.scrollSnapType).toBe("x mandatory");
    expect(screen.getByTestId("green-tick")).toBeTruthy();
    expect(screen.getByTestId("public-profile-stats").textContent).toMatch(/52KFollowers.*3\.4%Engagement/);
    fireEvent.click(screen.getByTestId("profile-photo-open"));
    expect(screen.getByTestId("profile-photo-lightbox")).toBeTruthy();
    cleanup();
    render(<PhotoLedHeaderMobile c={c} photoUrl="p.jpg" verified={false} />);
    expect(screen.queryByTestId("green-tick")).toBeNull();
  });
  it("work: one grid, '3 videos · 2 brands', brand chips filter, most viewed first", () => {
    render(<PortfolioCoversMobile items={items} />);
    expect(screen.getByTestId("public-portfolio-covers").textContent).toMatch(/3 videos · 2 brands.*Most viewed/);
    const tiles = () => screen.getAllByTestId("work-tile").map((t) => t.getAttribute("href"));
    expect(tiles()).toEqual(["https://instagram.com/reel/2", "https://instagram.com/reel/1", "https://instagram.com/reel/3"]);
    fireEvent.click(screen.getByText("Mamaearth 1"));
    expect(tiles()).toEqual(["https://instagram.com/reel/3"]);
  });
  it("GreenTick is a green scalloped badge", () => {
    const { container } = render(<GreenTick />);
    expect(container.querySelector("path").getAttribute("fill")).toBe("#16A34A");
  });
});

describe("BRD §24 filters — new fields", () => {
  const list = [
    { user_id: "1", name: "A", gender: "female", languages: ["Hindi", "English"], ig_followers: 50000, avg_views_30d: 100, engagement_rate: 1, city: "Jaipur", instagram_handle: "a" },
    { user_id: "2", name: "B", gender: "male", languages: ["Tamil"], ig_followers: 5000, avg_views_30d: 900, engagement_rate: 7, city: "Chennai", youtube: "yt" },
  ];
  it("gender / language / platform / follower range / cities / sort", () => {
    expect(extraMatch(list[0], { gender: "female" })).toBe(true);
    expect(extraMatch(list[1], { gender: "female" })).toBe(false);
    expect(extraMatch(list[1], { languages: ["Tamil"] })).toBe(true);
    expect(extraMatch(list[0], { platforms: ["YouTube"] })).toBe(false);
    expect(extraMatch(list[0], { fmin: 10000, fmax: 100000 })).toBe(true);
    expect(extraMatch(list[1], { fmin: 10000 })).toBe(false);
    expect(extraMatch(list[1], { cities: ["Chennai"] })).toBe(true);
    expect(sortCreators(list, "engagement").map((c) => c.user_id)).toEqual(["2", "1"]);
    expect(filterCount({ categories: [], followers: [], gender: "male", languages: ["Hindi", "Tamil"], sort: "reach" })).toMatchObject({ gender: 1, language: 2, sort: 1 });
    expect(applyFilters(list, "", { categories: [], followers: [], maxRate: 0, city: "", gender: "male" }).map((c) => c.user_id)).toEqual(["2"]);
  });
});

describe("animations + popups + status bar + Explore Back", () => {
  it("PushPage slides a deeper page in and the parent back", () => {
    const { rerender, container } = render(<PushPage page={null}>hub</PushPage>);
    expect(container.firstChild.getAttribute("data-push")).toBe("none");
    rerender(<PushPage page="kyc">kyc</PushPage>);
    expect(container.firstChild.getAttribute("data-push")).toBe("push");
    rerender(<PushPage page={null}>hub</PushPage>);
    expect(container.firstChild.getAttribute("data-push")).toBe("pop");
  });
  it("source checks", () => {
    const rd = (p) => readFileSync(p, "utf8");
    expect(rd("src/components/common/Popup.jsx")).toContain("setTimeout(() => { locked = true; lockScroll(); }, 320)");
    expect(rd("src/components/layout/StatusBarSync.jsx")).toContain("data-statusbar-page");
    expect(rd("src/components/chat/mobile/ChatBoxMobile.jsx")).toContain('data-statusbar-page="#FFFFFF"');
    expect(rd("src/components/explore/mobile/ExploreMobile.jsx")).toContain("EXPLORE_KEEP");
    expect(rd("src/pages/creator/CreatorSettings.jsx")).toContain("<PushPage page={mobileScreen || null}");
    expect(rd("ios-app/scripts/mac-prepare.sh")).toContain("topEdgeEffect.isHidden = true");
    // popups keep a light blur (Ravi: "thoda sa blur rakhna")
    expect(rd("src/components/explore/mobile/ExploreMobile.jsx")).toContain("backdrop-blur-[3px]");
  });
  it("brand onboarding: Instagram required, bio saved, new brands go to review", () => {
    const rd = (p) => readFileSync(p, "utf8");
    const ob = rd("src/pages/onboarding/BrandOnboardingMobile.jsx");
    expect(ob).not.toContain("No Instagram? Set up manually");
    expect(ob).not.toContain("Continue without Instagram");
    expect(ob).toContain("instagram_bio:");
    expect(rd("backend/auth_routes.ts")).toContain('if (!hadBrandRow) (payload as any).profile_status = "under_review";');
    expect(rd("src/App.jsx")).toContain("<BrandReviewGate><BrandCampaignCreate /></BrandReviewGate>");
    expect(rd("backend/brands_routes.ts")).toContain('"instagram_bio", "instagram_followers"');
    expect(rd("src/components/instagram/InstagramFetchButton.jsx")).toContain('updateField("bio"');
    expect(rd("backend/instagramConnect.ts")).toContain("patch.bio = String(stats.biography)");
  });
});

import { brandReviewBlock } from "../backend/brandQuality";
describe("server: a brand under review can't post (Ravi 18 Nov)", () => {
  const db = (status) => ({ from: () => ({ select: () => ({ eq: () => ({ maybeSingle: async () => ({ data: status === undefined ? null : { profile_status: status } }) }) }) }) });
  it("blocks only under_review; never blocks when the check fails", async () => {
    expect((await brandReviewBlock(db("under_review"), "b1"))?.code).toBe("BRAND_UNDER_REVIEW");
    expect(await brandReviewBlock(db("approved"), "b1")).toBeNull();
    expect(await brandReviewBlock(db(undefined), "b1")).toBeNull();
    expect(await brandReviewBlock({ from: () => { throw new Error("down"); } }, "b1")).toBeNull();
  });
  it("wired into campaign create / send-for-review and UGC brief create (drafts still allowed)", () => {
    const c = readFileSync("backend/campaigns_routes.ts", "utf8");
    expect(c.match(/brandReviewBlock\(/g).length).toBe(2);
    expect(c).toContain('if (req.body.status !== "draft") {\n      // v451');
    expect(readFileSync("backend/ugc_routes.ts", "utf8")).toContain("brandReviewBlock(privilegedSupabase || supabase");
  });
});

describe("brands under review: no dark review popup / banner (Ravi 18 Nov)", () => {
  it("Layout shows the review banner + auto popup only to non-brand accounts", () => {
    const l = readFileSync("src/components/layout/Layout.jsx", "utf8");
    expect(l).toContain("user.profile_status === 'under_review' && !isBrandLike(user.role)");
    expect(l).toContain("{!isBrandLike(user?.role) && <UnderReviewBanner");
  });
});

import { chatPushPayload } from "../backend/push_routes";
describe("chat push (ready; waits for Ravi's OK on the locked chat file)", () => {
  it("payload: sender, text, opens that chat, one tag per chat", () => {
    expect(chatPushPayload({ senderName: "Aanya Shah", text: "Pls share   final script", threadId: "th_1" }))
      .toEqual({ title: "Aanya Shah", body: "Pls share final script", url: "/chat?thread=th_1", tag: "chat-th_1" });
    expect(chatPushPayload({ senderName: "x", text: "📎 Attached file: a.pdf", type: "attachment", threadId: "t" }).body).toBe("📎 Sent a file");
    expect(chatPushPayload({ staff: true, text: "hi", threadId: "t" }).title).toBe("Ybex Support");
  });
  it("app open = no chat banner (web worker + native apps)", () => {
    expect(readFileSync("public/push-sw.js", "utf8")).toContain('wins.some((c) => c.visibilityState === "visible")');
    for (const f of ["ios-app/capacitor.config.json", "android-app/capacitor.config.json"]) {
      expect(JSON.parse(readFileSync(f, "utf8")).plugins.PushNotifications.presentationOptions).toEqual(["badge"]);
    }
  });
});
