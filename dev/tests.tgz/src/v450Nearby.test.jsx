import { describe, it, expect } from "vitest";
import { creatorPoint, withDistance, withinRadius, distanceLabel, clusterPins, project, unproject, kmToPx, radiusCounts } from "./components/explore/nearby/nearbyLogic";
import { cleanBranch, selectOne, placeFromNominatim, MAX_BRANCHES } from "../backend/brandLocations";
import { readFileSync } from "fs";

const branch = { id: "b1", name: "Head Office", city: "Ghaziabad", area: "Gaur City 2", lat: 28.6094, lng: 77.4319 };
const cs = [
  { user_id: "a", name: "A", city: "Noida" },
  { user_id: "b", name: "B", city: "Ghaziabad" },
  { user_id: "c", name: "C", city: "Jaipur" },
  { user_id: "d", name: "D", city: "" },
];

describe("v450 Explore near you", () => {
  it("creators sit on their city centre (never a home), unknown city left out, nearest first", () => {
    expect(creatorPoint({ city: "" })).toBeNull();
    const l = withDistance(cs, branch);
    expect(l.map((c) => c.user_id)).toEqual(["b", "a", "c"]);
    expect(withinRadius(l, 25).map((c) => c.user_id)).toEqual(["b", "a"]);
    expect(radiusCounts(l)[100]).toBe(2);
  });
  it("same city says 'Also from …', else km", () => {
    const l = withDistance(cs, branch);
    expect(distanceLabel(l[0], branch)).toBe("Also from Ghaziabad");
    expect(distanceLabel(l[2], branch)).toMatch(/^\d+ km away$/);
  });
  it("mercator round-trip, km→px, pins merge into +N", () => {
    const p = project(28.6, 77.2, 10); const back = unproject(p.x, p.y, 10);
    expect(back.lat).toBeCloseTo(28.6, 4); expect(back.lng).toBeCloseTo(77.2, 4);
    expect(kmToPx(10, 28.6, 10)).toBeGreaterThan(50);
    const c = clusterPins([{ id: 1, x: 0, y: 0, item: 1 }, { id: 2, x: 10, y: 10, item: 2 }, { id: 3, x: 200, y: 0, item: 3 }]);
    expect(c.map((x) => x.n)).toEqual([2, 1]);
  });
  it("branches: India only, named, unique, max 5, one selected", () => {
    expect(cleanBranch({ lat: 51.5, lng: -0.1, name: "x" }, []).error).toBeTruthy();
    expect(cleanBranch({ lat: 28.6, lng: 77.4, name: "" }, []).error).toBeTruthy();
    const one = cleanBranch({ lat: 28.6, lng: 77.4, name: "Head Office" }, []).branch;
    expect(cleanBranch({ lat: 28.7, lng: 77.4, name: "head office" }, [one]).error).toMatch(/already/);
    const five = Array.from({ length: MAX_BRANCHES }, (_, i) => ({ ...one, id: `b${i}`, name: `B${i}` }));
    expect(cleanBranch({ lat: 28.7, lng: 77.4, name: "New" }, five).error).toMatch(/up to 5/);
    expect(selectOne(five, "b2").filter((b) => b.selected).map((b) => b.id)).toEqual(["b2"]);
  });
  it("address from OpenStreetMap", () => {
    const p = placeFromNominatim({ lat: "28.6", lon: "77.4", address: { suburb: "Sector 16C", city: "Ghaziabad", state: "Uttar Pradesh", postcode: "201009" } });
    expect(p).toMatchObject({ label: "Sector 16C", city: "Ghaziabad", area: "Sector 16C", lat: 28.6, lng: 77.4 });
  });
  it("Explore: no '· verified' count line; location line + Map button for brands", () => {
    const src = readFileSync("src/components/explore/mobile/ExploreMobile.jsx", "utf8");
    expect(src).not.toMatch(/verified`\s*:\s*""/);
    expect(src).toContain("<LocationLine");
    expect(src).toContain("<MapButton");
    expect(src).toContain("brand/area-demand");
  });
});

import { agencyPromptDue } from "./components/profile/mobile/brand/AgencyPromptSheet";
import { shouldShowAgencyPrompt } from "../backend/brandLocations";
describe("v451 brand panel fixes (BRD Part B)", () => {
  it("agency popup: first open, once more after 15 days, then never; never for agencies / after claiming", () => {
    const now = Date.parse("2026-12-01T00:00:00Z");
    for (const f of [agencyPromptDue, shouldShowAgencyPrompt]) {
      expect(f({}, false, now)).toBe(true);
      expect(f({}, true, now)).toBe(false);
      expect(f({ agency_prompt_count: 1, agency_prompt_dismissed_at: "2026-11-25T00:00:00Z" }, false, now)).toBe(false);
      expect(f({ agency_prompt_count: 1, agency_prompt_dismissed_at: "2026-11-10T00:00:00Z" }, false, now)).toBe(true);
      expect(f({ agency_prompt_count: 2 }, false, now)).toBe(false);
      expect(f({ agency_prompt_done: true }, false, now)).toBe(false);
    }
  });
  it("source checks: views line, purple tabs, payments page, nav logo, banner carousel, hub header", () => {
    const rd = (p) => readFileSync(p, "utf8");
    expect(rd("src/pages/brand/brandHome/ActiveBriefsCarousel.jsx")).toContain(`data-testid="brief-applicant-chips"`); // v451: chips, no views
    expect(rd("src/components/campaigns/mobile/BrandCampaignDetailMobile.jsx")).toContain("bg-[#F1EBFE] border-[#D9C8FB] text-[#6D28D9]");
    const pay = rd("src/components/payments/BrandPaymentsMobile.jsx");
    expect(pay).not.toContain("Pay creators safely with escrow");
    expect(pay).toContain("Start your first campaign");
    expect(rd("src/components/layout/BottomNav.jsx")).toContain('label: "Profile", // v450');
    expect(rd("src/pages/brand/BrandHomeMobile.jsx")).toContain('scrollSnapType: "x mandatory"');
    const hub = rd("src/components/profile/mobile/BrandProfileMobile.jsx");
    expect(hub).not.toContain("Edit company details");
    expect(hub).toContain("Share profile");
    expect(hub).not.toContain("Are you an agency?</h4>");
    expect(rd("backend/campaignValue.ts")).toContain("countCampaignView(");
    expect(rd("backend/campaigns_routes.ts")).not.toContain("countCampaignView"); // locked file stays untouched
  });
});

import { igHandleProblem, cleanGstin, looksLikeWebsite } from "./lib/brandSignup";
import { scheduleSlots } from "./components/admin/blog/BlogList";
import { shortSeoTitle, seoTitle } from "../backend/blogSeo";
import { cleanGst } from "../backend/auth_routes";
describe("v451 Ravi's list: brand IG/GST, blog SEO title + schedule, blob logo", () => {
  it("IG handle: email / website / spaces refused; leading @ fine", () => {
    expect(igHandleProblem("pradeepkumarsurname02@gamil.com")).toMatch(/email/);
    expect(igHandleProblem("mybrand.com")).toMatch(/website/);
    expect(igHandleProblem("www.mybrand.in")).toMatch(/website/);
    expect(igHandleProblem("my brand")).toMatch(/spaces/);
    expect(igHandleProblem("@my_brand.in_store")).toBe("");
    expect(igHandleProblem("my_brand")).toBe("");
    expect(igHandleProblem("https://instagram.com/my_brand")).toBe("");
  });
  it("GST + website checks", () => {
    expect(cleanGstin("22aaaaa0000a1z5")).toBe("22AAAAA0000A1Z5");
    expect(cleanGst("22AAAAA0000A1Z5")).toBe("22AAAAA0000A1Z5");
    expect(cleanGstin("12345")).toBe("");
    expect(looksLikeWebsite("mybrand.com")).toBe(true);
    expect(looksLikeWebsite("instagram.com/mybrand")).toBe(false);
  });
  it("blog SEO title: short, own, never cut with …", () => {
    const long = "How Much Should You Pay Instagram Influencers in India in 2026: A Complete Rate Card Guide for Brands";
    expect(seoTitle({ title: long })).not.toContain("…");
    expect(seoTitle({ title: long }).length).toBeLessThanOrEqual(60);
    expect(seoTitle({ title: "Reels guide" })).toBe("Reels guide | YBEX");
    expect(seoTitle({ title: long, meta_title: "Influencer Rates India 2026" })).toBe("Influencer Rates India 2026 | YBEX");
    expect(shortSeoTitle("SEO Title | YBEX Blog")).toBe("SEO Title");
  });
  it("bulk schedule: one post every N days at the set time", () => {
    const s = scheduleSlots(3, "2026-11-20", "10:30", 2);
    expect(s.map((d) => [d.getDate(), d.getHours(), d.getMinutes()])).toEqual([[20, 10, 30], [22, 10, 30], [24, 10, 30]]);
    expect(scheduleSlots(2, "2026-11-20", "09:00", 0).map((d) => d.getDate())).toEqual([20, 20]);
  });
  it("blob: logos never saved; Admin shows the brand's IG link; HIW footer", () => {
    const rd = (p) => readFileSync(p, "utf8");
    expect(rd("src/pages/onboarding/BrandOnboardingMobile.jsx")).toContain('!String(formData.logoUrl).startsWith("blob:") ? { logo: formData.logoUrl }');
    expect(rd("backend/auth_routes.ts")).toContain("if (/^blob:/i.test(String(rawLogo))) rawLogo = \"\";");
    expect(rd("src/components/admin/AdminUsersTab.jsx")).toContain('data-testid="admin-brand-ig"');
    expect(rd("src/components/whatsNew/WhatsNewPopup.jsx")).toContain('data-testid="hiw-stories-mute"');
    expect(rd("backend/blog_routes.ts")).toContain('router.post("/admin/blog/schedule"');
  });
});

// ── v455: tester pass on the brand map ──
import { branchOwnerId, setupBrandLocationRoutes } from "../backend/brandLocations";
import { areaNotifyCount, areaNotifyMessage } from "../backend/campaignValue";
import { getNotificationRedirectPath } from "./components/shared/NotificationItem";

function fakeRouter() {
  const routes = {};
  const add = (m) => (p, h) => { routes[`${m} ${p}`] = h; };
  return { routes, get: add("GET"), post: add("POST"), delete: add("DELETE") };
}
async function call(r, key, { user, body = {}, params = {}, query = {} }) {
  let out = { status: 200, body: null };
  const res = { status(s) { out.status = s; return res; }, json(b) { out.body = b; return res; }, set() { return res; } };
  await r.routes[key]({ body, params, query, user }, res);
  return out;
}

describe("v455 brand map — tester fixes", () => {
  it("only brands own branches; a team member shares the brand owner's list", () => {
    expect(branchOwnerId({ user_id: "c1", role: "creator" })).toBe("");
    expect(branchOwnerId({ user_id: "b1", role: "brand" })).toBe("b1");
    expect(branchOwnerId({ user_id: "t1", role: "brand", parent_brand_id: "b1" })).toBe("b1");
  });

  it("renaming a branch keeps the selected branch; adding one selects the new one; creators get 403", async () => {
    const r = fakeRouter();
    let who = { user_id: `bt${Date.now()}`, role: "brand" };
    setupBrandLocationRoutes(r, { parseAuthUser: async () => who });
    const a = await call(r, "POST /brand/branches", { body: { name: "Head Office", lat: 26.85, lng: 75.81, city: "Jaipur" } });
    const b = await call(r, "POST /brand/branches", { body: { name: "Store", lat: 26.9, lng: 75.8, city: "Jaipur" } });
    expect(b.body.branches.find((x) => x.selected).name).toBe("Store");
    const ho = a.body.branch.id;
    const ren = await call(r, "POST /brand/branches", { body: { id: ho, name: "Jaipur HQ", lat: 26.85, lng: 75.81, city: "Jaipur" } });
    expect(ren.body.branches.find((x) => x.id === ho).name).toBe("Jaipur HQ");
    expect(ren.body.branches.find((x) => x.selected).name).toBe("Store");
    who = { user_id: "c9", role: "creator" };
    expect((await call(r, "GET /brand/branches", {})).status).toBe(403);
    who = null;
    expect((await call(r, "GET /geo/search", { query: { q: "Jaipur" } })).status).toBe(401);
  });

  it("'Notify me' really notifies: counts approved new creators, clear message, opens Explore", () => {
    expect(areaNotifyCount([{ profile_status: "approved" }, { profile_status: "pending" }, { profile_status: "LIVE" }])).toBe(2);
    expect(areaNotifyMessage(1, "jaipur")).toBe("1 new creator joined near Jaipur — open Explore to see them on the map.");
    expect(areaNotifyMessage(3, "new delhi")).toMatch(/^3 new creators joined near New Delhi/);
    expect(getNotificationRedirectPath({ type: "creators_nearby" }, "brand")).toBe("/explore");
  });

  it("map: Back closes it, zoom out exists, drag only after 6 px, intro saved once, dialog role", () => {
    const fs = require("fs"); const path = require("path");
    const read = (p) => fs.readFileSync(path.join(__dirname, p), "utf8");
    const map = read("components/explore/nearby/NearbyMapView.jsx");
    expect(map).toMatch(/useBackToClose\(true, onList\)/);
    expect(map).toContain('data-testid="map-zoom-out"');
    expect(map).toMatch(/introSaved\.current = true/);
    expect(map).toContain('role="dialog"');
    expect(read("components/explore/nearby/SlippyMap.jsx")).toMatch(/Math\.hypot\(dx, dy\) < 6/);
    const loc = read("components/explore/nearby/LocationScreens.jsx");
    expect(loc).toMatch(/useBackToClose\(true, onBack\)/);
    expect(loc).toMatch(/longPressed\.current/);
    expect(read("components/common/PWAInstallPrompt.jsx")).toMatch(/sheetsInHistory\(\)\.length > 0/);
    expect(read("lib/popupRules.js")).toMatch(/Date\.now\(\) - selfBackAt < 900/);
    const ex = read("components/explore/mobile/ExploreMobile.jsx");
    expect(ex).toMatch(/api\.get\("brand\/area-notify"/);
    expect(ex).toMatch(/}, 1500\);/);
  });
});
