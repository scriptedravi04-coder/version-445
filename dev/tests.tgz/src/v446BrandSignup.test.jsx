// v446: brand sign-up — links, resume mapping, helpers.
import { describe, it, expect, beforeEach } from "vitest";
import { welcomeSkipTarget } from "./pages/app/AppWelcome";
import { deepLinkQuery } from "./lib/native";
import { oneLineFromBio, industryFor, BUSINESS_TYPES } from "./lib/brandSignup";
import { playStoreUrl } from "./components/common/PlayStoreBanner";
import { needsMatchAnswers, questionForOpen } from "./components/brand/BrandMatchCard";
import { resumeFor, brandPageFromMobile } from "./lib/onboardingProgress";
import { saveEntryRole, readEntryRole, clearEntryRole, saveInstallReferrer } from "./lib/signupSource";

describe("v446 · role=brand links", () => {
  beforeEach(() => { try { localStorage.clear(); } catch { /* ignore */ } });
  it("skips the role cards when the link (or the Play install) asked for a role", () => {
    expect(welcomeSkipTarget("?role=brand&utm_source=ig")).toBe("/app/continue/brand?utm_source=ig");
    expect(welcomeSkipTarget("?role=agency")).toBe("/app/continue/brand");
    expect(welcomeSkipTarget("?role=creator")).toBe("/app/continue/creator");
    expect(welcomeSkipTarget("")).toBe("");
    expect(welcomeSkipTarget("?role=brand&demo=1")).toBe("");
    expect(welcomeSkipTarget("?ref=AB", "brand")).toBe("/app/continue/brand?ref=AB");
  });
  it("install referrer role is kept until the first sign-in", () => {
    saveInstallReferrer("utm_source=meta&role=brand");
    expect(readEntryRole()).toBe("brand");
    clearEntryRole();
    expect(readEntryRole()).toBe("");
    expect(saveEntryRole("bank")).toBe("");
  });
  it("app links keep their query", () => {
    expect(deepLinkQuery("com.ybex.app://app?role=brand#x")).toBe("?role=brand");
    expect(deepLinkQuery("com.ybex.app://app")).toBe("");
    expect(playStoreUrl({}, "signup", "brand")).toContain(encodeURIComponent("role=brand"));
    expect(playStoreUrl({}, "signup")).not.toContain("role");
  });
});

describe("v446 · 3-screen sign-up", () => {
  it("old saved pages land on the nearest new screen", () => {
    expect(resumeFor("brand_mobile", { flow: "brand_mobile", page: "industry", pos: { step: 2 } })).toEqual({ screen: 2 });
    expect(resumeFor("brand_mobile", { flow: "brand_mobile", page: "campaign_more", pos: { step: 7 } })).toEqual({ screen: 3 });
    expect(resumeFor("brand_mobile", { flow: "brand_mobile", page: "contact", pos: { step: 3, v: 2 } })).toEqual({ screen: 3 });
    expect(brandPageFromMobile(2)).toBe("business");
  });
  it("bio → one line; business type → industry", () => {
    expect(oneLineFromBio("Handmade skincare 🌿 for oily skin. Ships pan-India | DM to order #skincare")).toBe("Handmade skincare for oily skin.");
    expect(industryFor("cafe")).toBe("Food");
    expect(industryFor("creator")).toBe("");
    expect(BUSINESS_TYPES.map((t) => t.id)).toEqual(["shop", "d2c", "app", "cafe", "salon", "agency", "creator"]);
  });
  it("v447: Brand Home asks ONE question per app open", () => {
    const p = { user_id: "b1" };
    const st = (o) => ({ opens: 1, skipAt: -99, answeredAt: -99, done: [], ...o });
    expect(questionForOpen(p, st({ opens: 1 }), false)).toBe(null);                     // first open: explore
    expect(questionForOpen(p, st({ opens: 2 }), false).field).toBe("campaign_types");
    expect(questionForOpen(p, st({ opens: 2 }), true)).toBe(null);                      // has a brief
    expect(questionForOpen(p, st({ opens: 3, answeredAt: 3, done: ["campaign_types"] }), false)).toBe(null);
    expect(questionForOpen(p, st({ opens: 4, done: ["campaign_types"] }), false).field).toBe("budget_range");
    expect(questionForOpen(p, st({ opens: 3, skipAt: 2 }), false)).toBe(null);          // Later → wait
    expect(questionForOpen(p, st({ opens: 5, skipAt: 2 }), false).field).toBe("campaign_types");
    const all = { campaign_types: ["paid"], budget_range: "₹2L+", preferred_creator_size: "Any size", preferred_niches: "Beauty" };
    expect(questionForOpen(all, st({ opens: 9 }), false)).toBe(null);
    expect(needsMatchAnswers(all)).toBe(false);
    expect(needsMatchAnswers(null)).toBe(false);
  });
});
