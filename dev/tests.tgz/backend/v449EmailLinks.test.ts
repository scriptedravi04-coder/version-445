import { describe, it, expect } from "vitest";
import { linkifyBody, broadcastEmail, HTML_MARK } from "./emailBroadcasts";

const PLAY = "https://play.google.com/store/apps/details?id=com.ybex.app&referrer=role%3Dcreator%26ref%3DYBEX-DB946998";

describe("v449 email body links", () => {
  it("shows only the label for 'Label → URL' lines", () => {
    const out = linkifyBody(`Android? Get the app → ${PLAY.replace(/&/g, "&amp;")}`);
    expect(out).toContain("Android? Get the app");
    expect(out).toContain('alt="Get it on Google Play"');
    expect(out).not.toContain(">https://");
  });
  it("shortens bare Play Store links", () => {
    expect(linkifyBody(PLAY)).toContain('alt="Get it on Google Play"');
  });
  it("full broadcast html never prints the raw long url as text", () => {
    const { html } = broadcastEmail({ subject: "x", body_text: `Hi\n\nAndroid? Get the app → ${PLAY}` }, { email: "a@b.com", name: "A" });
    expect(html).toContain("en_badge_web_generic.png");
    expect(html).not.toMatch(/>\s*https:\/\/play\.google\.com/);
  });
  it("other links stay short text links", () => {
    expect(linkifyBody("Site → https://ybexmedia.in/signup")).toContain(">Site</a>");
  });
  it("leaves plain text alone", () => {
    expect(linkifyBody("Cheers,\nRavi")).toBe("Cheers,\nRavi");
  });
  it("designed HTML body is sent as-is with name + unsubscribe filled", () => {
    const { html } = broadcastEmail({ subject: "x", body_text: `${HTML_MARK}<p>Hi {{first_name}}</p><a href="{{UNSUBSCRIBE}}">u</a>` }, { email: "a@b.com", name: "Ri<b>ya K" });
    expect(html.startsWith("<p>Hi Ri&lt;b&gt;ya</p>")).toBe(true);
    expect(html).not.toContain("{{UNSUBSCRIBE}}");
    expect(html).not.toContain(HTML_MARK);
  });
});
