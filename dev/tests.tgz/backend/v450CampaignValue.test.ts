import { describe, it, expect } from "vitest";
import { appItemsValue, campaignValueTotal, citiesLabel, tickerLines, demandRow, demandSummary, CV_BASE, CV_START_ISO } from "./campaignValue";
import { rollFrames } from "../src/components/common/CampaignValueBanner";

describe("v450 campaign value banner", () => {
  it("starts at ₹14,60,363 and moves only with real items / admin entries", () => {
    expect(CV_BASE).toBe(1460363);
    expect(campaignValueTotal([], 0)).toBe(1460363);
    const after = "2026-11-20T00:00:00Z", before = "2026-11-01T00:00:00Z";
    const app = appItemsValue([{ budget_max: 5000, max_creators: 4, created_at: after }, { budget_max: 9999, max_creators: 9, created_at: before }], [{ budget: 1000, max_creators: 3, created_at: after }]);
    expect(app).toBe(23000);
    expect(campaignValueTotal([{ id: "a", amount: 2000, note: "x", at: "", by: "" }, { id: "b", amount: -5000, note: "y", at: "", by: "" }], app)).toBe(1460363 + 23000 - 3000);
    expect(CV_START_ISO > before).toBe(true);
  });
  it("cities label and ticker come from real creator cities", () => {
    expect(citiesLabel(111)).toBe("110+ cities");
    expect(citiesLabel(7)).toBe("7 cities");
    const t = tickerLines([{ city: "Jaipur" }, { city: "jaipur " }, { city: "Delhi NCR" }, { city: "New Delhi" }, { city: "Pan India" }]);
    expect(t.lines[0]).toBe("Jaipur: 2 creators on Ybex");
    expect(t.lines[1]).toBe("Delhi: 2 creators on Ybex");
    expect(t.cityCount).toBe(2);
  });
  it("digits roll from the last seen number to the new one", () => {
    const f = rollFrames(1460363, 1462363, 10);
    expect(f[f.length - 1]).toBe(1462363);
    expect(f.every((x) => x >= 1460363 && x <= 1462363)).toBe(true);
    expect(rollFrames(0, 5)).toEqual([5]);
  });
  it("area demand keeps only empty searches, grouped by place", () => {
    const r1 = demandRow({ city: "Jaipur", area: "Malviya Nagar", lat: 26.85, lng: 75.8, radius_km: 100, results: 0 }, "b1");
    const r2 = demandRow({ city: "Jaipur", area: "Malviya Nagar", results: 0 }, "b2");
    const r3 = demandRow({ city: "Noida", results: 12 }, "b3");
    const s = demandSummary([r1, r2, r3]);
    expect(s).toHaveLength(1);
    expect(s[0]).toMatchObject({ city: "Jaipur", area: "Malviya Nagar", brands: 2, searches: 2 });
  });
});
